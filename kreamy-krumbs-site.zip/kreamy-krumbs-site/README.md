# Kreamy Krumbs

A one-page website for Kreamy Krumbs, a 100% eggless home bakery. Built with React, Vite, and Tailwind CSS.

## What's inside

- Full menu (cakes, cheesecakes, cupcakes, brownies, donuts) with search and category filters
- Product detail popups that link straight to Instagram DM for ordering
- Photo gallery
- About, Why Choose Us, and FAQ sections
- Mobile-first, since most traffic will come from the Instagram bio link

All ordering happens through Instagram — there is no cart, no prices, no checkout. Tapping "Order on Instagram" anywhere on the site opens your Instagram profile.

## How to publish this as a real website (using Vercel)

You don't need to know how to code to do this. Follow these steps:

### Step 1: Create accounts (both free)
1. Go to [github.com](https://github.com) and sign up if you don't have an account.
2. Go to [vercel.com](https://vercel.com) and sign up using your GitHub account (click "Continue with GitHub").

### Step 2: Upload this project to GitHub
1. On GitHub, click the **+** icon (top right) → **New repository**.
2. Name it `kreamy-krumbs`, keep it Public, and click **Create repository**.
3. On the next page, click **uploading an existing file**.
4. Drag this entire folder's contents (all files and folders you downloaded) into the upload box.
5. Click **Commit changes** at the bottom.

### Step 3: Deploy on Vercel
1. Go to [vercel.com/new](https://vercel.com/new).
2. Find your `kreamy-krumbs` repository in the list and click **Import**.
3. Vercel will automatically detect it's a Vite project — you don't need to change any settings.
4. Click **Deploy**.
5. Wait about a minute. Vercel will give you a live URL like `kreamy-krumbs.vercel.app`.

### Step 4: Add the link to your Instagram bio
1. Open Instagram, go to your profile, tap **Edit Profile**.
2. Tap the **Links** field and paste your new Vercel URL.
3. Save.

That's it — your website is now live and linked from your Instagram bio.

### Making changes later
Any time you want to update the menu, photos, or text: edit the files on GitHub (or ask Claude to help you edit `src/App.jsx`), commit the change, and Vercel will automatically redeploy the site with the update within about a minute. No need to repeat the import step.

### Using your own domain (optional)
If you later buy a custom domain (e.g. `kreamykrumbs.com`), you can connect it under your Vercel project's **Settings → Domains** tab, and Vercel will walk you through pointing it at your site.

## Local development (optional, for developers)

```bash
npm install
npm run dev
```

This starts a local server, usually at `http://localhost:5173`.

To build a production version:

```bash
npm run build
```

The output goes to the `dist/` folder.
